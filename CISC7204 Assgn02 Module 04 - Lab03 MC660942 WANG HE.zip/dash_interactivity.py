"""CISC7204 Assignment 2, Module 04 Lab 03.

Individual student: WANG HE (MC660942)
AI disclosure: OpenAI Codex assisted with code completion, troubleshooting,
and documentation. The application was run locally and reviewed.
"""
import os
from pathlib import Path
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html

DATA_URL = Path(__file__).resolve().parent / "airline_data.csv"
data = pd.read_csv(DATA_URL, encoding="ISO-8859-1", dtype={"Div1Airport": str, "Div1TailNum": str, "Div2Airport": str, "Div2TailNum": str})

app = Dash(__name__)
app.title = "Airline Delay Dashboard"
app.layout = html.Div([
    html.H1("Airline Performance Dashboard", style={"textAlign": "center", "color": "#503D36", "fontSize": 40}),
    html.P("Individual submission — WANG HE (MC660942)", style={"textAlign": "center", "fontWeight": "bold", "color": "#1f4e79"}),
    html.Label("Select Year", style={"fontWeight": "bold"}),
    dcc.Input(id="input-year", type="number", min=2010, max=2020, step=1, value=2010, style={"height":"50px", "fontSize":35}),
    dcc.Graph(id="line-plot"),
], style={"maxWidth": "1100px", "margin": "0 auto", "fontFamily": "Arial"})

@app.callback(Output("line-plot", "figure"), Input("input-year", "value"))
def update_graph(input_year):
    selected = data[data["Year"] == int(input_year or 2010)]
    line_data = selected.groupby("Month", as_index=False)["ArrDelay"].mean()
    return px.line(line_data, x="Month", y="ArrDelay", markers=True, color_discrete_sequence=["green"],
                   title=f"Monthly Average Arrival Delay in {int(input_year or 2010)}")

if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=int(os.getenv("PORT", "8050")))
