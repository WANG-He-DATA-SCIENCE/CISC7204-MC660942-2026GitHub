"""Module 04 Lab 04: five-output Dash callback.
AI assistance: code review, corrections, and execution checks by OpenAI Codex.
"""
import os
from pathlib import Path
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html

# Task 1: read the course dataset bundled with this project.
data = pd.read_csv(Path(__file__).parent / 'airline_data.csv',
    encoding='ISO-8859-1', dtype={'Div1Airport': str, 'Div1TailNum': str,
                                'Div2Airport': str, 'Div2TailNum': str})
delay_specs = [
    ('carrier-plot', 'CarrierDelay', 'Carrier'),
    ('weather-plot', 'WeatherDelay', 'Weather'),
    ('nas-plot', 'NASDelay', 'National air system'),
    ('security-plot', 'SecurityDelay', 'Security'),
    ('late-plot', 'LateAircraftDelay', 'Late aircraft'),
]

# Tasks 2 and 3: layout and named output graph components.
app = Dash(__name__)
app.title = 'Flight Details Statistics Dashboard'
app.layout = html.Div([
    html.H1('Flight Details Statistics Dashboard',
        style={'textAlign':'center', 'color':'#503D36', 'fontSize':35}),
    html.P('WANG HE (MC660942)', style={'textAlign':'center'}),
    html.Div(['Input Year: ', dcc.Input(id='input-year', value=2010,
        type='number', min=2010, max=2020, step=1,
        style={'height':'35px', 'fontSize':30})], style={'fontSize':35}),
    html.Div([dcc.Graph(id='carrier-plot', style={'width':'50%'}),
              dcc.Graph(id='weather-plot', style={'width':'50%'})], style={'display':'flex'}),
    html.Div([dcc.Graph(id='nas-plot', style={'width':'50%'}),
              dcc.Graph(id='security-plot', style={'width':'50%'})], style={'display':'flex'}),
    html.Div(dcc.Graph(id='late-plot'), style={'width':'65%'}),
], style={'maxWidth':'1500px', 'margin':'0 auto', 'fontFamily':'Arial'})

# Task 4: calculate each monthly average separately by reporting airline.
def compute_info(airline_data, entered_year):
    year = int(entered_year if entered_year is not None else 2010)
    selected = airline_data[airline_data['Year'] == year]
    return tuple(selected.groupby(['Month','Reporting_Airline'], as_index=False)[column].mean()
                 for _, column, _ in delay_specs)

# Tasks 5 and 6: one input updates the figures of all five graphs.
@app.callback([Output(graph_id, 'figure') for graph_id, _, _ in delay_specs],
              Input('input-year', 'value'))
def get_graph(entered_year):
    averages = compute_info(data, entered_year)
    return [px.line(frame, x='Month', y=column, color='Reporting_Airline',
        title=f'{label} delay by airline ({entered_year or 2010})',
        labels={column:'Average delay (minutes)'})
        for frame, (_, column, label) in zip(averages, delay_specs)]

if __name__ == '__main__':
    app.run(debug=False, host='127.0.0.1', port=int(os.getenv('PORT','8050')))
