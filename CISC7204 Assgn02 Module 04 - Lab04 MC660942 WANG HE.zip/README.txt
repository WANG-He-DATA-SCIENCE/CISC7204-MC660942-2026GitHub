CISC7204 Assignment 02 — MC660942_WANG_HE

Tested with Python 3.12.14.
Install: python -m pip install -r requirements.txt
Run one script at a time from this folder:
  python flight_delay.py
  python flight_details.py
Open http://127.0.0.1:8050 in a browser. Stop with Ctrl+C before starting another script. Data files are included. PORT may be set to use a different local port.

Code and screenshots were checked with AI assistance; the student remains responsible for reviewing and explaining the submitted work.

Dataset authenticity
The bundled data were downloaded from the instructor-specified IBM course URLs. This establishes the authenticity of the teaching files, not an independent audit of every underlying measurement.
