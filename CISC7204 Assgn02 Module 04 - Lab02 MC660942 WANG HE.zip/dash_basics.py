"""CISC7204 Assignment 2, Module 04 Lab 02.

Individual student: WANG HE (MC660942)
AI disclosure: OpenAI Codex assisted with code completion, troubleshooting,
and documentation. The application was run locally and reviewed.
"""
import os
from pathlib import Path
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html

DATA_URL = Path(__file__).resolve().parent / "airline_data.csv"

data = pd.read_csv(DATA_URL, encoding="ISO-8859-1", dtype={"Div1Airport": str, "Div1TailNum": str, "Div2Airport": str, "Div2TailNum": str})
data = data.sample(n=500, random_state=42)

distance_group = data.groupby("DistanceGroup", as_index=False)["Flights"].sum()
figure = px.pie(distance_group, values="Flights", names="DistanceGroup", title="Distance Group Proportion by Flights")

app = Dash(__name__)
app.title = "Airline On-time Performance Dashboard"
app.layout = html.Div([
    html.H1("Airline On-time Performance Dashboard", style={"textAlign": "center", "color": "#503D36", "fontSize": 50}),
    html.P("Individual submission — WANG HE (MC660942)", style={"textAlign": "center", "fontWeight": "bold", "color": "#1f4e79"}),
    html.P("Proportion of distance group (250 mile distance interval group) by flights.", style={"textAlign": "center", "color": "#F57241"}),
    dcc.Graph(id="distance-group-chart", figure=figure),
], style={"maxWidth": "1100px", "margin": "0 auto", "fontFamily": "Arial"})

if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=int(os.getenv("PORT", "8050")))
